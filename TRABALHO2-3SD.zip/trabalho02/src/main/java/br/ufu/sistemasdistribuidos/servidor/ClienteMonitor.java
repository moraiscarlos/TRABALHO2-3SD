/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufu.sistemasdistribuidos.servidor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author carlo
 */


public class ClienteMonitor {

    //Envia requisição de monitorar e espera respostas
    public void monitorar(String command) throws SocketException{
        byte[] sendData = new byte[1400];
	byte[] receiveData = new byte[1024];				
	DatagramSocket clientSocket = new DatagramSocket();
       InetAddress IPAddress = null;
        try {
                IPAddress = InetAddress.getByName("localhost");
        } catch (UnknownHostException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
        }


        sendData = command.getBytes();

        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
        try {
                clientSocket.send(sendPacket);
        } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }
        try {
                Thread.sleep(150);
        } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }
        new Thread(){
            @Override
            public void run(){
                while(true){
                    DatagramPacket receivePacket1 = new DatagramPacket(receiveData, receiveData.length);
                    try {
                            clientSocket.receive(receivePacket1);
                    } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                    }


                    String respostaServidor = new String(receivePacket1.getData());

                    System.out.println(readResponse(respostaServidor));
                }
             }  
       }.start();
    }
    
    //ler resposta
     public static String readResponse(String txt) {
		int estado = 0;
		int v = 0;
		String value = "";
		String r = "";
		for (int i = 0; i < txt.length(); i++) {
			if(estado == 0) {
				if(txt.charAt(i) == ':') {
					v = Integer.parseInt(value);
					estado++;
				}else {
					value = value + txt.charAt(i);
				}
			}else {
				return txt.substring(i,i+v);
			}
		}
		return null;
	}
}
