/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufu.sistemasdistribuidos.servidor;

import static br.ufu.sistemasdistribuidos.servidor.Cliente.chavesMonitoradas;
import static br.ufu.sistemasdistribuidos.servidor.Cliente.port;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jpdna.grpchello.HelloWorldClient;

/**
 *
 * @author carlo
 */
public class ClienteGRPC {
        static ArrayList<String> chavesMonitoradas = new ArrayList<String>();
    	public static void main(String args[]) throws Exception {
            // THREAD DE LEITURA
		new Thread(){
			@Override
			public void run(){
				while(true){
					String comando = null;
					BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		        
					/* CRIANDO MENU */
					System.out.println(" -------------- MENU ------------  ");
					System.out.println("|             C - CREATE	  |");
					System.out.println("|             R - READ		  |");
					System.out.println("|             U - UPDATE	  |");
					System.out.println("|             D - DELETE	  |");
					System.out.println("|             M - MONITORAR	  |");
					System.out.println("|             E - EXIT		  |");
					System.out.println(" --------------------------------  ");
					
					// OPÇÃO DO MENU
					System.out.println(" > Digite sua opção: ");
					String opcao = null;
					try {
						opcao = inFromUser.readLine();
					} catch (IOException e3) {
						// TODO Auto-generated catch block
						e3.printStackTrace();
					}
					
					
					if ( opcao.equals("E")){
						System.out.println("Até mais....");
						System.exit(0);
					}
					
					// INSERINDO A CHAVE
					System.out.println(" > Digite a chave: ");
					String chave = null;
					try {
						chave = inFromUser.readLine();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				
					// VERIFICANDO LIMITE BYTES DA CHAVE
					if (chave.getBytes().length > 20){
						System.out.println("Chave ultrapassou limite de bytes!");
						return;
					}
					
					// COMPARAÇOES COM OPÇÃO (CREATE AND UPDATE) 
					if ((opcao.equals("C")) || (opcao.equals("U")) ) {
						
						System.out.println(" > Digite o valor: ");
						String valor = null;
						try {
							valor = inFromUser.readLine();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					    
						if (valor.getBytes().length > 1361){		
							System.out.println("Valor ultrapassou limite de bytes!");
							return;
						}
						
					    comando = opcao+chave.length()+ ":" + chave + valor.length()+ ":" +valor;
						
						
					}else if ( (opcao.equals("R")) || (opcao.equals("D"))){ // COMPARAÇÕES COM OPÇÃO( READ AND DELETE)
						
						comando = opcao+chave.length()+ ":" + chave;
						
					}else if ( opcao.equals("M")){
                                               if(chavesMonitoradas.contains(chave)){
                                                   System.out.println("Chave já está sendo monitorada");
                                               }else{
                                                   comando = opcao+chave.length()+ ":" + chave;
                                               }
					}else{
						System.out.println("Opção inválida!");
                                                continue;
					}
                                        //Criar cliente grpc
                                        HelloWorldClient client = new HelloWorldClient("localhost", 50051);
                                        try {
                                          client.exe(comando);
                                          if(comando.charAt(0)!='M') client.shutdown();
                                        } catch (InterruptedException ex) {
                                            ex.printStackTrace();
                                        } catch (Exception ex) {
                                            Logger.getLogger(ClienteGRPC.class.getName()).log(Level.SEVERE, null, ex);
                                        }
				}
			}
		}.start();

            
        }
}
