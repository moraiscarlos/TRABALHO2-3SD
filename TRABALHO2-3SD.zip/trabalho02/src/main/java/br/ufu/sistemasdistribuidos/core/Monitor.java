/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufu.sistemasdistribuidos.core;

import io.grpc.stub.StreamObserver;
import java.math.BigInteger;
import java.net.InetAddress;
import java.util.ArrayList;
import org.jpdna.grpchello.HelloResponse;

public class Monitor {

	private BigInteger chave;
	boolean grpc;
        InetAddress IPAddress;
        int port;
        StreamObserver<HelloResponse> response;

    public BigInteger getChave() {
        return chave;
    }

    public void setChave(BigInteger chave) {
        this.chave = chave;
    }

    public boolean isGrpc() {
        return grpc;
    }

    public void setGrpc(boolean grpc) {
        this.grpc = grpc;
    }

    public InetAddress getIPAddress() {
        return IPAddress;
    }

    public void setIPAddress(InetAddress IPAddress) {
        this.IPAddress = IPAddress;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public StreamObserver<HelloResponse> getResponse() {
        return response;
    }

    public void setResponse(StreamObserver<HelloResponse> response) {
        this.response = response;
    }
 
}
