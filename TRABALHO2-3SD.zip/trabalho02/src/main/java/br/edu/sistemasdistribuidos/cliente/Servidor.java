/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.sistemasdistribuidos.cliente;

import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.ufu.sistemasdistribuidos.core.Comando;
import br.ufu.sistemasdistribuidos.core.Monitor;
import io.grpc.stub.StreamObserver;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jpdna.grpchello.HelloResponse;
import org.jpdna.grpchello.HelloWorldServer;
import org.json.JSONArray;
import org.json.JSONObject;


public class Servidor {

	// CRIANDO MAPA <BIGINTEGER,STRING>
	static Map<BigInteger, String> mapa = new HashMap<BigInteger, String>();
	public static ArrayList<Monitor> monitores = new ArrayList<Monitor>();
	static Comando cabeca = null;
	static Comando calda  = null;
	
	static Comando cabecaLog = null;
	static Comando caldaLog  = null;
        static int time = 0;
	static DatagramSocket serverSocket;
	
	static byte[] receiveData = new byte[1400];
        static byte[] sendData = new byte[1400];

	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
        serverSocket = new DatagramSocket(9876);
        //THREAD MONITORAMENTO
        new Thread(){
        @Override
        public void run(){
       final HelloWorldServer server = new HelloWorldServer();
            try {
                server.start();
            } catch (Exception ex) {
                Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                server.blockUntilShutdown();
            } catch (InterruptedException ex) {
                Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            }
        	}
        }.start();
       
        
                // THREAD DE SNAPSHOT 
        new Thread(){
        	@Override
        	public void run(){
                       while(true){
                           if(time == 30){
                               time = 0;
                               createSnapshot();
                           }else{
                               time++;
                           }
                           try {
                               Thread.sleep(1000);
                           } catch (InterruptedException ex) {
                               Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
                           }
                       }
        	}
        }.start();
       
        
        // THREAD DE LEITURA 
        new Thread(){
        	@Override
        	public void run(){

        		System.out.println("Servidor iniciado!");
        		
        		boolean flag = false;
                        for(int i=3; i>0; i--){
                            try {
                                int qtd = readSnapshot(i);
                                if(qtd == 0){
                                    System.out.println("tamanho");
                                    continue;
                                }else{
                                    flag = true;
                                    break;
                                }
                            } catch (Exception e) {
                                System.out.println("error");
                                continue;
                            }
                        }
                        if(!flag) try {
                               lerLOG();
                        } catch (UnsupportedEncodingException ex) {
                            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
                        }
        		while(true){

        			// RECEBE COMANDO (OPCAO,KEY,VALUE)
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    try {
						serverSocket.receive(receivePacket);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                    
                    Comando t = null;
					try {
						t = readCommand(receivePacket.getData());
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    
                    
                    //String sentence = new String( receivePacket.getData());
                    //System.out.println("RECEIVED: " + sentence);
                    
                    InetAddress IPAddress = receivePacket.getAddress();
                    int port = receivePacket.getPort();
                    
                    System.out.println("Cliente conectado: " + IPAddress + ":" + port);
                    
                    push(t.getTipo(), t.getChave(), t.getValor(), false, IPAddress, port, null);
                    pushLOG(t.getTipo(), t.getChave(), t.getValor());
                    
                   //String capitalizedSentence = sentence.toUpperCase();
                   //sendData = capitalizedSentence.getBytes();
                    
                    //DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
                    //serverSocket.send(sendPacket);

                 } 
    
        	}
        }.start();
       
        // THREAD DE PROCESSAMENTO
        new Thread(){
        	@Override
        	public void run(){
        		while(true){  
                               
        			Comando t = pull();
                                
        			if ( t != null){
        			
                                    String resposta = CRUD(t, t.isGrpc(), t.getIPAddress(), t.getPort(), t.getResponse());
        	          
                                    if(t.isGrpc()){
                                        if(!t.getTipo().equals("M")){
                                            try {
                                                HelloResponse reply = HelloResponse.newBuilder().setMessage(resposta).build();
                                                t.getResponse().onNext(reply);
                                                t.getResponse().onCompleted();
                                    
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }

                                    }else{
                                        
                                          sendData = (resposta.length()+":"+resposta).getBytes();

                                            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, t.getIPAddress(), t.getPort());
                                            try {
                                                                            serverSocket.send(sendPacket);
                                                                    } catch (IOException e) {
                                                                            // TODO Auto-generated catch block
                                                                            e.printStackTrace();
                                                                    }
                                            }

                        
        			}
        			
        			
        			
        			try {
						Thread.sleep(2500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
        		 } 
        	    
        	}
        }.start();
        
        
        // THREAD DE LOG
        new Thread(){
        	@Override
        	public void run(){
        		while(true){
        			
        			Comando t = pullLOG();
        			if ( t != null){
        				String log = t.getTipo()+(t.getChave()+"").length()+":"+t.getChave();
            			if ((t.getTipo().equals("C")) || (t.getTipo().equals("U") )){
            				log = log + t.getValor().length() + ":" +t.getValor();
            			}
            
                                List<String> lines = null;
                                Path path = Paths.get("log.txt");
                                try {
                                                lines = Files.readAllLines(path, StandardCharsets.UTF_8);
                                        } catch (IOException e2) {
                                                // TODO Auto-generated catch block
                                                e2.printStackTrace();
                                        }

                                FileWriter arq = null;
                                        try {
                                                arq = new FileWriter("log.txt");
                                            PrintWriter gravarArq = new PrintWriter(arq);

                                    for (int i = 0; lines!= null && i < lines.size(); i++) {
                                                        gravarArq.println(lines.get(i));
                                                }
                                    gravarArq.println(log);
                                    gravarArq.close();
                                        } catch (IOException e1) {
                                                // TODO Auto-generated catch block
                                                e1.printStackTrace();
                                        }
    						
            			
        			}
        			
        			try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
        		}
        		
        	} 	
        }.start();
        		
	}
	
	// DESMONTO STRING SEPARANDO EM PARTES
	public static Comando readCommand(byte[] data) throws UnsupportedEncodingException {
		String command = new String(data, "UTF-8");
		String type = null, key = "", value = "";
		int estado = 0,  v = 0;
		String number = "";
		for (int i = 0; i < command.length(); i++) {
			if(estado == 0) {
				type = command.charAt(i)+"";
				estado = 1;
			}else if(estado == 1 || estado == 4) {
				if(command.charAt(i) == ':') {
					estado++;
					v = Integer.parseInt(number);
				}else {
					number = number + command.charAt(i);
				}
			}else if(estado == 2) {
				key = key + command.charAt(i);
				v--;
				if(v == 0) {
					estado = 3;
				}
			}else if(estado == 3) {
				if(type.equals("D") || type.equals("R")) {
					break;
				}else {
					i--;
					number = "";
					estado = 4;
				}
			}else if(estado == 5) {
				value = value + command.charAt(i);
				v--;
				if(v==0) {
					break;
				}
			}
			
		}
		Comando t = new Comando();
		t.setTipo(type);
		t.setChave(new BigInteger(key));
		t.setValor(value);
		
		
		
		return t;
	}
	
	// ADICIONANDO EM FILA
	public static void push(String tipo, BigInteger chave, String valor, boolean grpc, InetAddress IPAddress, int port, StreamObserver<HelloResponse> response){
		System.out.println("br.edu.sistemasdistribuidos.cliente.Servidor.push()" + grpc);
		Comando temp = new Comando();
		temp.setTipo(tipo);
		temp.setChave(chave);
		temp.setValor(valor);
                temp.setGrpc(grpc);
                if(grpc){
                    temp.setResponse(response);
                }else{
                    temp.setIPAddress(IPAddress);
                    temp.setPort(port);
                }
		
		
		if (cabeca == null){
			cabeca = temp;
		}
		if (calda != null){
			calda.setProximo(temp);
		}
		
		calda = temp;
		
	}
	
	// RETIRANDO DA FILA
	public static Comando pull(){
		if (cabeca ==  null){
			return null;
		}
		
		Comando temp = cabeca;
		
		if (cabeca.getProximo() == null){
			cabeca = null;
		}else {
			cabeca = cabeca.getProximo();
		}
		
		return temp;
	}
	
	
	// COLOCANDO EM FILA LOG
	public static void pushLOG(String tipo, BigInteger chave, String valor){
		
		Comando temp = new Comando();
		temp.setTipo(tipo);
		temp.setChave(chave);
		temp.setValor(valor);
		
		if (cabecaLog == null){
			cabecaLog = temp;
		}
		if (caldaLog != null){
			caldaLog.setProximo(temp);
		}
		
		caldaLog = temp;
		
	}
	
	// RETIRANDO DA FILA
	public static Comando pullLOG(){
		if (cabecaLog ==  null){
			return null;
		}
		
		Comando temp = cabecaLog;
		
		if (cabecaLog.getProximo() == null){
			cabecaLog = null;
		}else {
			cabecaLog = cabecaLog.getProximo();
		}
		
		return temp;
	}
	
	// COMANDO CRUD
        public static String CRUD(Comando t){
            return CRUDf(t, false, null, -1, null);
        }
        public static String CRUD(Comando t, boolean grpc, InetAddress IPAddress, int port, StreamObserver<HelloResponse> response ){
             return CRUDf(t, grpc, IPAddress, port, response);
        }
	public static String CRUDf(Comando t, boolean grpc, InetAddress IPAddress, int port, StreamObserver<HelloResponse> response ){
		String resposta = null;
                
		switch (t.getTipo()) {
		case "C":
                        if(mapa.containsKey(t.getChave())){
                            resposta = "Chave já existe!";
                        }else{
                            mapa.put(t.getChave(), t.getValor());
                            resposta = "Adicionado com sucesso!";
                            monitorar(t.getTipo(), t);
                        }
			break;
		case "U":
                        if(!mapa.containsKey(t.getChave())){
                            resposta = "Chave não existe!";
                        }else{
                            mapa.put(t.getChave(), t.getValor());
                            resposta = "Atualizado com sucesso!";
                            monitorar(t.getTipo(), t);
                        }
			break;
		case "R":
                        if(!mapa.containsKey(t.getChave())){
                            resposta = "Chave não existe!";
                        }else{
                            resposta = "Chave: "+t.getChave()+ " Valor: "+mapa.get(t.getChave());
                            monitorar(t.getTipo(), t);
                        }
			
										
			break;
                case "M":
                        Monitor m = new Monitor();
                        m.setGrpc(grpc);
                        m.setChave(t.getChave());
                        if(grpc){
                            m.setResponse(response);
                        }else{
                            m.setIPAddress(IPAddress);
                            m.setPort(port);
                        }
                        monitores.add(m);
                        resposta = "Chave sendo monitorada";
                        break;
		case "D":
                        if(!mapa.containsKey(t.getChave())){
                            resposta = "Chave não existe!";
                        }else{
                            mapa.remove(t.getChave());	
                            resposta = "Deletado com sucesso!";
                            monitorar(t.getTipo(), t);
                        }
			break;
		default:
			break;
		}
		
		return resposta;
	}
	//Executada toda vez q um crud é realizado
        public static void monitorar(String comando, Comando t){
            ArrayList<Monitor> remover = new ArrayList<Monitor>();
            for(Monitor m : monitores){
                String resposta = "";
                String plus = !t.isGrpc() ? " | <"+ t.getIPAddress()+":"+t.getPort()+">" : "";
                if(comando.equals("C")){
                        resposta = "Chave("+m.getChave()+") criada. Valor: " + t.getValor() + plus;
                }else if(comando.equals("R")){
                        resposta = "Chave("+m.getChave()+") lida. Valor: " + mapa.get(t.getChave())+ plus;
                }else if(comando.equals("U")){
                        resposta = "Valor da chave("+m.getChave()+") atualizada: " + t.getValor() + plus;
                }else if(comando.equals("D")){
                        resposta = "Chave("+m.getChave()+") deletada " + plus;
                }
                if (m.getChave().equals(t.getChave())){
                    if(m.isGrpc()){
                        HelloResponse reply = HelloResponse.newBuilder().setMessage(resposta).build();
                        m.getResponse().onNext(reply);
                        m.getResponse().onCompleted();
                        remover.add(m);
                    }else{
                        sendData = (resposta.length()+":"+resposta).getBytes();
                        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, m.getIPAddress(), m.getPort());
                        try {
                            System.out.println("ENVIEI MONITOR");
                            serverSocket.send(sendPacket);
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }
            }
            for (Monitor m: remover) {
                monitores.remove(m);
            }
	}
	
	
	
	// PERCORRER LOG
	public static void lerLOG() throws UnsupportedEncodingException{
		
		List<String> lines = null;
		Path path = Paths.get("log.txt");
		try {
			lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			return;
		}
		
		for (int i = 0; i < lines.size(); i++) {
                  
			CRUD(readCommand(lines.get(i).getBytes()));
			
		}
		
	}
	 public static void createSnapshot(){
             JSONArray ja = new JSONArray();
             Object[] a = mapa.keySet().toArray();
             for(int i=0; i<a.length; i++){
                 JSONObject jo = new JSONObject(); // criou OBJETO
                 jo.put(((BigInteger)a[i])+"", mapa.get(((BigInteger)a[i]))); //atributo para objeto (chave,valor)
                 ja.put(jo); // colocando objeto no array
             }
             
             Path path2 = Paths.get("snapshot2.txt");
             Path path3 = Paths.get("snapshot3.txt");
             String lines = null;
            try {
                   lines = new String(Files.readAllBytes(path2), StandardCharsets.UTF_8);
            } catch (IOException e2) {
                    // TODO Auto-generated catch block
                    e2.printStackTrace();
            }

            FileWriter arq = null;
            try {
                arq = new FileWriter("snapshot1.txt");
                PrintWriter gravarArq = new PrintWriter(arq);
                gravarArq.println(lines);
                gravarArq.close();
            } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
            }
            
            try {
                   lines = new String(Files.readAllBytes(path3), StandardCharsets.UTF_8);
            } catch (IOException e2) {
                    // TODO Auto-generated catch block
                    e2.printStackTrace();
            }


            try {
                arq = new FileWriter("snapshot2.txt");
                PrintWriter gravarArq = new PrintWriter(arq);
                gravarArq.println(lines);
                gravarArq.close();
            } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
            }
            
            try {
                arq = new FileWriter("snapshot3.txt");
                PrintWriter gravarArq = new PrintWriter(arq);
                gravarArq.println(ja.toString());
                gravarArq.close();
            } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
            }
             
        }
         
         public static int readSnapshot(int v){
            Path path3 = Paths.get("snapshot"+v+".txt");
            int qtd;
             String lines = null;
            try {
                   lines = new String(Files.readAllBytes(path3), StandardCharsets.UTF_8);
            } catch (IOException e2) {
                    // TODO Auto-generated catch block
                    e2.printStackTrace();
            }
            JSONArray ja = new JSONArray(lines);
            qtd = ja.length();
            for(int i = 0; i<ja.length(); i++){
                JSONObject jo = ja.getJSONObject(i);
                Object[] k = jo.keySet().toArray();
                mapa.put(((BigInteger)k[0]), jo.getString(k[0]+""));
            }
            return qtd;
        }
}
