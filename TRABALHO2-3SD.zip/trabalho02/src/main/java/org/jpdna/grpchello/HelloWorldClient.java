
package org.jpdna.grpchello;

import br.ufu.sistemasdistribuidos.servidor.Cliente;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Scanner;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * A simple client that requests a greeting from the {@link HelloWorldServer}.
 */
public class HelloWorldClient {
  private static final Logger logger = Logger.getLogger(HelloWorldClient.class.getName());

  private final ManagedChannel channel;
  private final GreeterGrpc.GreeterBlockingStub blockingStub;

  /** Construct client connecting to HelloWorld server at {@code host:port}. */
  public HelloWorldClient(String host, int port) {
    channel = ManagedChannelBuilder.forAddress(host, port)
        .usePlaintext(true)
        .build();
    blockingStub = GreeterGrpc.newBlockingStub(channel);
  }

  public void shutdown() throws InterruptedException {
    channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
  }
  
  //Envia comando crud e recebe resposta
  public void crud(String command){
     HelloRequest request = HelloRequest.newBuilder().setName(command).build();
     HelloResponse response = blockingStub.sayHello(request);
     System.out.println("Resposta do servidor: " + response.getMessage());
  }
  
  //Enviar requisão de monitorar e espera resposta do servidor
  public void monitorar(String command){
      System.out.println("Monitorando chave");
      new Thread(){
            @Override
            public void run(){
                while(true){
                    HelloRequest request = HelloRequest.newBuilder().setName(command).build();
                    HelloResponse response = blockingStub.sayHello(request);
                    System.out.println(response.getMessage());
                }
            }  
    }.start();
  }
  /** Say hello to server. */
  //Chama funções acima
  public void greet(String command) throws InterruptedException {
     if(command.charAt(0)=='M'){
         monitorar(command);
     }else{
         crud(command);
     }
    	
        
    /*while(true){
        HelloRequest request = HelloRequest.newBuilder().setName("teste").build();
        HelloResponse response = blockingStub.sayHello(request);
        System.out.println("T2");
           
        System.out.println(response.getMessage());
        /*try {
          for(int i=0; i < Cliente.chavesMonitoradas.size(); i++){
              String chave = Cliente.chavesMonitoradas.get(i);
              boolean status = Cliente.chaveMonitoradasStatus.get(i);
              int cont = Cliente.chaveMonitoradasCont.get(i);
              String sendString = (status ? "ATT:"+chave+":"+cont : "CON:"+chave);
              HelloRequest request = HelloRequest.newBuilder().setName(sendString).build();
              
              HelloResponse response = blockingStub.sayHello(request);
              Cliente.readMonitorResponse(response.getMessage(), i);
          }
         
          //logger.info("Greeting: " + response.getMessage());
        } catch (RuntimeException e) {
          logger.log(Level.WARNING, "RPC failed", e);
          return;
        }

        Thread.sleep(1000);
   }*/
     
  }

  /**
   * Greet server. If provided, the first element of {@code args} is the name to use in the
   * greeting.
   */
  //Chama a função greet
  public void exe(String t) throws Exception {
    HelloWorldClient client = new HelloWorldClient("localhost", 50051);
    try {
      /* Access a service running on the local machine on port 50051 */
      client.greet(t);
    } finally {
      if (t.charAt(0) != 'M') client.shutdown();
    }
  }
}
