

package org.jpdna.grpchello;

import br.edu.sistemasdistribuidos.cliente.Servidor;
import static br.edu.sistemasdistribuidos.cliente.Servidor.push;
import static br.edu.sistemasdistribuidos.cliente.Servidor.pushLOG;
import static br.edu.sistemasdistribuidos.cliente.Servidor.readCommand;
import br.ufu.sistemasdistribuidos.core.Comando;
import br.ufu.sistemasdistribuidos.core.Monitor;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.logging.Level;

import java.util.logging.Logger;

/**
 * Server that manages startup/shutdown of a {@code Greeter} server.
 */
public class HelloWorldServer {
  private static final Logger logger = Logger.getLogger(HelloWorldServer.class.getName());

  /* The port on which the server should run */
  private int port = 50051;
  private Server server;

  public void start() throws Exception {
    server = ServerBuilder.forPort(port)
        .addService(GreeterGrpc.bindService(new GreeterImpl()))
        .build()
        .start();
    logger.info("Server started, listening on " + port);
    Runtime.getRuntime().addShutdownHook(new Thread() {
      @Override
      public void run() {
        // Use stderr here since the logger may have been reset by its JVM shutdown hook.
        System.err.println("*** shutting down gRPC server since JVM is shutting down");
        HelloWorldServer.this.stop();
        System.err.println("*** server shut down");
      }
    });
  }

  private void stop() {
    if (server != null) {
      server.shutdown();
    }
  }

  /**
   * Await termination on the main thread since the grpc library uses daemon threads.
   */
  public void blockUntilShutdown() throws InterruptedException {
    if (server != null) {
      server.awaitTermination();
    }
  }

  /**
   * Main launches the server from the command line.
   */

  private class GreeterImpl implements GreeterGrpc.Greeter {

    @Override
    public void sayHello(HelloRequest req, StreamObserver<HelloResponse> responseObserver) {
  
        try {
            readCommand(req.getName(), responseObserver);
     
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(HelloWorldServer.class.getName()).log(Level.SEVERE, null, ex);
        }
   
    }
  }
  //Le os comandos recebidos dos clientes e empilha
  public void readCommand(String c, StreamObserver<HelloResponse> helloResponse) throws UnsupportedEncodingException{
      Comando t = Servidor.readCommand(c.getBytes());
      push(t.getTipo(), t.getChave(), t.getValor(), true, null, -1, helloResponse);
      if(c.charAt(0)!='M')pushLOG(t.getTipo(), t.getChave(), t.getValor());
  }
  
}
